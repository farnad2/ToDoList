package com.farnadsoft.to_do_list.Server;

public class ServerConfig {

	// your FCM Advance Push Admin Panel Url
	public static final String BASE_URL = "http://cuty.ir/push";
	
	//for Multiple App only
	public static final String APP_TYPE = "ADVANCE_PUSH";
	
	//=============== DO NOT CHANGE THIS
	public static final String REGISTRATION_URL = "/user/register"; // Do not change it if you have not customized web Admin panel.
	//===============
}
